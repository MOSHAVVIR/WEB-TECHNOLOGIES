
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN HERE</title>
</head>
<body>

<div>
	<h1>
			<center>
    		<?php include '../VIEW/HEADER.php' ?>
			</center>
			</h1>  
	<center>

<?php

	$myfile = fopen("../DATA/ADMIN.txt", "r") or die("Unable to open file!");
	while( $line=fgets($myfile))
{
	$words = explode(",",$line);
	$myemail=$words[0];
	$mypass=$words[1];
	
}
fclose($myfile);
	if(isset($_POST['login']))
	{
		$email=$_POST['email'];
		$password=$_POST['password'];
		if($email==$myemail and $password==$mypass)
		{
			setcookie('email',$email,time()+60);
			session_start();
			$_SESSION['email']=$email;
			header('location:../VIEW/LOGOUT.php');
			
			
		}
		else
		{
			echo "EMAIL OR PASSWORD IS INVALID.<br><br> CLICK HERE TO <a href='/FB/VIEW/LOGIN.php'> <br><br> TRY AGAIN</a>";
			
		}

	}
	else
	{
		header("location:../VIEW/LOGIN.php");
	}

?>
</center>
</div>
<h1>
	<center>
    <?php include '../VIEW/FOOTER.php' ?>
	</center>
</h1> 
</body>
</html>