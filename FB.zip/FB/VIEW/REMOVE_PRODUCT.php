<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1>
    <?php
    $id = $name = $type = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $id= $_POST['id'];

      $myfile = fopen("../DATA/PRODUCT.txt", "r") or die("Unable to open file!");
          $counter=0;
          while ($line = fgets($myfile)) {
              $words = explode(",",$line);
              if($id==$words[0]){
                $row_number = $counter;
                break;
              }
              else{
                $counter++;
              }
          }
          fclose($myfile);

          $file_out = file("../DATA/PRODUCT.txt");
          unset($file_out[$row_number]);
          file_put_contents("../DATA/PRODUCT.txt", implode("", $file_out));


    }


     ?>

     <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
       <label for="">ENTER PRODUCT ID TO REMOVE</label>
       <br><br>
       <input type="text" name="id"placeholder="Enter The Product ID" value="<?php echo $id; ?>"required>
       <br><br>
       <input type="submit" name="REMOVE" value="REMOVE">
       <br><br>
       <a href="VIEW_PRODUCT.php">SHOW PRODUCT </a>
     </form>

     <h2>
  <center>
    <?php include '../VIEW/FOOTER.php' ?>
  </center>
</h2>
</center>
  </body>
</html>
