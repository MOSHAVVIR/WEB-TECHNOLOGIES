<!DOCTYPE html>
<html>
<head>
	
	<title>LOGIN</title>

</head>
<body>
	<center>
		<div>
			<h1>
			<center>
    		<?php include '../VIEW/HEADER.php' ?>
			</center>
			</h1>  
			
			<h1>LOGIN HERE</h1>
			<form action="/wt/FB/VALIDATION/LOGIN_VALIDATION.php" method="post">

				<label>Email:  </label>
				<input type="text" name="email" placeholder="Enter The Email" required>
				<br><br>
				<label>Password:</label>
				<input type="text" name="password" placeholder="Enter The Password" required>
				<br><br>
				<input type="submit" value="Login" name="login" >
				<br/> <br/>
				<center><a href="FORGETPASSWORD.php">FORGET PASSWORD </a> </center>

				
			</form>
		</div>
	    
	</center>

<h1>
<center>
<?php include '../VIEW/FOOTER.php' ?>
</center>
</h1>    

</body>
</html>

