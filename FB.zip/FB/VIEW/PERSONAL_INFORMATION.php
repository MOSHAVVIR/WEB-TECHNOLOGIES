<!DOCTYPE html>
<html>
<head>
	<title>PERSONAL INFORMATION</title>
</head>
<body>
	<center><h1><?php include '../VIEW/HEADER.php' ?></h1></center>
	<center>
		
		<h2>YOUR INFORMATION</h2>
		
	    
	</center>    

</body>
</html>
