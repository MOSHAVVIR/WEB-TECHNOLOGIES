<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1>
    <?php
    $id = $name = $type = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $id= $_POST['id'];

      $myfile = fopen("../DATA/ORDER.txt", "r") or die("Unable to open file!");
          $counter=0;
          while ($line = fgets($myfile)) {
              $words = explode(",",$line);
              if($id==$words[0]){
                $row_number = $counter;
                break;
              }
              else{
                $counter++;
              }
          }
          fclose($myfile);

          $file_out = file("../DATA/ORDER.txt");
          unset($file_out[$row_number]);
          file_put_contents("../DATA/ORDER.txt", implode("", $file_out));


    }


     ?>

     <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
       <label for="">ENTER ORDER ID TO CANCEL</label>
       <br><br>
       <input type="text" name="id"placeholder="Enter The Order ID" value="<?php echo $id; ?>"required>
       <br><br>
       <input type="submit" name="CANCEL" value="CANCEL">
       <br><br>
       <a href="VIEW_ORDER.php">SHOW ORDER </a>
     </form>

     <h2>
  <center>
    <?php include '../VIEW/FOOTER.php' ?>
  </center>
</h2>
</center>
  </body>
</html>
