<!DOCTYPE html>
<html>
<head>
	<title>ROOTS OF BANGLADESH</title>
</head>
<body>
	<center><h1><?php include '../VIEW/HEADER.php' ?></h1></center>

	<center><a href="LOGIN.php">LOGIN </a> </center>
	<br/>  
	<center><a href="REGISTRATION.php">REGISTRATION </a></center>
	

<h2>
	<center>
    <?php include '../VIEW/FOOTER.php' ?>
	</center>
</h2>	

</body>
</html>
