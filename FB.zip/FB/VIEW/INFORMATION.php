<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1> 
     <h2>YOUR INFORMATION</h2>
    <?php
      $firstname = $lastname= $email= $address= $phonenumber = "";
      $myfile = fopen("../DATA/DATA.txt", "r") or die("Unable to open file!");

      #fopen("../DATA/ADMIN.txt", "r")
        #fopen("data.txt", "a")

          while ($line = fgets($myfile)) {
              $words = explode(",",$line);
              $firstname = $words[0];
              $lastname = $words[1];
              $email = $words[2];
              $address = $words[3];
              $phonenumber = $words[4];
          }
          fclose($myfile);
    ?>
    <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
      <label for="">FIRST NAME - </label>
      <label for=""><?php echo $firstname; ?></label>
      <br><br>

      <label for="">LAST NAME - </label>
      <label for=""><?php echo $lastname; ?></label>
      <br><br>

      <label for="">EMAIL -  </label>
      <label for=""><?php echo $email; ?></label>
      <br><br>

      <label for="">ADDRESS - </label>
      <label for=""><?php echo $address; ?></label>
      <br><br>

      <label for="">PHONE NUMBER - </label>
      <label for=""><?php echo $phonenumber; ?></label>
      <br><br>

      <a href="UPDATE.php">UPDATE INFORMATION </a>
      <br><br>
      <a href="LOGOUT.php">GO TO HOME PAGE </a>

    </form>
    <h3><?php include '../VIEW/FOOTER.php' ?></h3>

    </center>

  </body>
</html>
