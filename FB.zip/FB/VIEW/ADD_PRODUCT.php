<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1>
    <?php
      $id = $name = $type = "";
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id= $_POST['id'];
        $name=$_POST['name'];
        $type=$_POST['type'];
        $user = fopen("../DATA/PRODUCT.txt", "a") or die("Unable to open file!");
        fwrite($user, $id. "," . $name. ",". $type);
        fwrite($user, "\n");
        fclose($user);
      }

    ?>
    <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

      <label for="id">PRODUCT ID</label>
      <input type="text" name="id"placeholder="Enter The ID" value="<?php echo $id; ?>"required>
      <br><br>

      <label for="name">PRODUCT NAME</label>
      <input type="text" name="name"placeholder="Enter The Name" value="<?php echo $name; ?>"required>
      <br><br>

      <label for="age">PRODUCT TYPE</label>
      <input type="text" name="type"placeholder="Enter The Type" value="<?php echo $type; ?>"required>
      <br><br>

      <input type="submit" name="ADD PRODUCT" value="ADD PRODUCT">
      <br><br>
      <a href="VIEW_PRODUCT.php"> VIEW PRODUCT</a>  ||   <a href="LOGOUT.php"> GO TO HOME PAGE </a>
    </form>
    </center>

    <h2>
  <center>
    <?php include '../VIEW/FOOTER.php' ?>
  </center>
</h2> 


  </body>
</html>
