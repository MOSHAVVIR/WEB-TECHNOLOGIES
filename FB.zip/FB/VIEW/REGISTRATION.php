<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1> 
     <h2>YOUR INFORMATION</h2>
    <?php
      $firstname = $lastname= $email= $address= $phonenumber = "";
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $firstname= $_POST['firstname'];
        $lastname=$_POST['lastname'];
        $email=$_POST['email'];
        $address=$_POST['address'];
        $phonenumber=$_POST['phonenumber'];
        $user = fopen("../DATA/DATA.txt", "a") or die("Unable to open file!");

        #fopen("../DATA/ADMIN.txt", "r")
        #fopen("data.txt", "a")

        fwrite($user, $firstname. "," .$lastname. ",". $email.",".$address.",".$phonenumber);
        fwrite($user, "\n");
        fclose($user);
      }

    ?>
    <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

      <label for="firstname">FIRST NAME</label>
      <input type="text" name="firstname"value="<?php echo $firstname; ?> "required>
      <br><br>

      <label for="lastname">LAST NAME</label>
      <input type="text" name="lastname"value="<?php echo $lastname; ?> "required>
      <br><br>

      <label for="email">EMAIL</label>
      <input type="text" name="email"value="<?php echo $email; ?> "required>
      <br><br>

      <label for="address">ADDRESS</label>
      <input type="text" name="address"value="<?php echo $address; ?> "required>
      <br><br>

      <label for="phonenumber">PHONE NUMBER</label>
      <input type="text" name="phonenumber"value="<?php echo $phonenumber; ?> "required>
      <br><br>

      <input type="submit" name="SUBMIT" value="SUBMIT">
      <br><br>
      <a href="TITLE.php"> GO TO HOME PAGE </a>
    </form>
    <h3><?php include '../VIEW/FOOTER.php' ?></h3>
    </center>

  </body>
</html>
