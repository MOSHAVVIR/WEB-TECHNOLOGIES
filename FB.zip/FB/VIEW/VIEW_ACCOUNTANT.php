<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1> 
     <h2>ACCOUNTANT INFORMATION</h2>
    <?php
      $id = $name = $age = "";
      $myfile = fopen("../DATA/ACCOUNTANT.txt", "r") or die("Unable to open file!");

          while ($line = fgets($myfile)) {
              $words = explode(",",$line);
              $id = $words[0];
              $name = $words[1];
              $age = $words[2];
          }
          fclose($myfile);
    ?>
    <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

      <label for="">ACCOUNTANT ID - </label>
      <label for=""><?php echo $id; ?></label>
      <br><br>

      <label for="">ACCOUNTANT NAME - </label>
      <label for=""><?php echo $name; ?></label>
      <br><br>

      <label for="">ACCOUNTANT AGE - </label>
      <label for=""><?php echo $age; ?></label>
      <br><br>
    </form>
    <a href="LOGOUT.php">GO TO HOME PAGE </a>
    <br><br>
    <h3><?php include '../VIEW/FOOTER.php' ?></h3>



    </center>


  </body>
</html>
