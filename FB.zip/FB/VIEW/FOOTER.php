<!DOCTYPE html>
<html>
<body>

<footer>
  <p>COPYRIGHT &copy; 1999-2020.</p>
</footer>

</body>
</html>