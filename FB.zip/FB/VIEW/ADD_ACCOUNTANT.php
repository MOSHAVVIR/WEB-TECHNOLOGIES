<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center>
      <h1><?php include '../VIEW/HEADER.php' ?></h1>
    <?php
      $id = $name = $age = "";
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id= $_POST['id'];
        $name=$_POST['name'];
        $age=$_POST['age'];
        $user = fopen("../DATA/ACCOUNTANT.txt", "a") or die("Unable to open file!");
        fwrite($user, $id. "," . $name. ",". $age);
        fwrite($user, "\n");
        fclose($user);
      }

    ?>
    <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

      <label for="id">ACCOUNTANT ID</label>
      <input type="text" name="id"placeholder="Enter The ID" value="<?php echo $id; ?>"required>
      <br><br>

      <label for="name">ACCOUNTANT NAME</label>
      <input type="text" name="name"placeholder="Enter The Name" value="<?php echo $name; ?>"required>
      <br><br>

      <label for="age">ACCOUNTANT AGE</label>
      <input type="text" name="age"placeholder="Enter The Age" value="<?php echo $age; ?>"required>
      <br><br>

      <input type="submit" name="ADD ACCOUNTANT" value="ADD ACCOUNTANT">
      <br><br>
      <a href="VIEW_ACCOUNTANT.php"> VIEW ACCOUNTANT </a>  ||   <a href="LOGOUT.php"> GO TO HOME PAGE </a>
    </form>
    </center>

    <h2>
  <center>
    <?php include '../VIEW/FOOTER.php' ?>
  </center>
</h2> 


  </body>
</html>
