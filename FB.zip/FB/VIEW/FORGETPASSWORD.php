<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<center><h1><?php include '../VIEW/HEADER.php' ?></h1></center>
	<br/>  <br/>  
	<center><h1>PLEASE CONTACT WITH THE OFFICE</h1></center>
	<br/>  <br/>  

<h1>
	<center>
    <?php include '../VIEW/FOOTER.php' ?>
	</center>
</h1>	
</body>
</html>