<!DOCTYPE html>
<html>
<head>
	<title>LOGOUT</title>
</head>
<body>
	<div>
			<center>
				<h1>
					<?php include '../VIEW/HEADER.php' ?>
				</h1>	
				
				<h2>WELCOME TO ROOTS OF BANGLADESH</h2>
			
			<a href="INFORMATION.php">PERSONAL INFORMATION </a>
			<br><br>
			
			<a href="ADD_ACCOUNTANT.php">ADD ACCOUNTANT </a> || <a href="REMOVE_ACCOUNTANT.php">REMOVE ACCOUNTANT </a>
			<br><br>
			<a href="ADD_PRODUCT.php">ADD PRODUCT </a> ||<a href="VIEW_PRODUCT.php">VIEW PRODUCT </a> || <a href="REMOVE_PRODUCT.php">REMOVE PRODUCT </a> || <a href="UPDATE_PRODUCT.php">UPDATE PRODUCT INFO. </a>
			<br><br>
			</center>
			<a href="ADD_ORDER.php">ADD ORDER </a>
			<br><br>
			<a href="VIEW_ORDER.php">VIEW ORDER </a>
			<br><br>
			<a href="CANCEL_ORDER.php">CANCEL ORDER </a>

				

				<center>
				<center><a href="TITLE.php">LOGOUT </a> </center>
				</center>



			    
	</div>
	<h1>
	<center>
    <?php include '../VIEW/FOOTER.php' ?>
	</center>
</h1>


</body>
</html>