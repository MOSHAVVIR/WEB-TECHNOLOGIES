<?php
session_start();

require_once "../model/pdo.php";


if ( isset( $_POST['fname']) && isset( $_POST['lname']) && isset( $_POST['email']) && isset( $_POST['password']) && isset( $_POST['address']) && isset( $_POST['phone'])) {

	// Data validation
	if ( strlen($_POST['fname']) < 1 || strlen($_POST['lname']) < 1 || strlen($_POST['email']) < 1 || strlen($_POST['password']) < 1 || strlen($_POST['address']) < 1  || strlen($_POST['phone'])  < 1 ) {
        $_SESSION['accountant-add-failed'] = 'Adding Accountant Failed! Please try with valid data.';
        header("Location: ../view/accountant-add.php");
        return;
	}
//   	if ( strpos($_POST['email'],'@') === false ) {
 //        $_SESSION['error'] = 'Bad data';
 //        header("Location: ../view/admin-register.php");
 //        return;
//   	}

	$sql = "INSERT INTO tbl_accountant (fname, lname, email, password, address, phone) VALUES (:fname, :lname, :email, :password,:address, :phone)";

	$stmt = $pdo->prepare($sql);
	$stmt->execute(array(
        ':fname' => $_POST['fname'],
        ':lname' => $_POST['lname'],
        ':email' => $_POST['email'],
        ':password' => $_POST['password'],
        ':address' => $_POST['address'],
        ':phone' => $_POST['phone']));
	$_SESSION['accountant-add-success'] = "Accountant Added Successfully!";
	header('Location: ../view/accountants-list.php');
	return;
}
?>


