<?php 
session_start();

require_once "../model/pdo.php";


if ( isset($_POST['email']) && isset($_POST['password']) ) {
	$query = "SELECT * FROM tbl_admin WHERE email = :email AND password = :password";
	// $query = "SELECT * FROM tbl_admin";
	$statement = $pdo->prepare($query);
	$statement->execute(array(
		'email' => $_POST['email'],
		'password' => $_POST['password']));

	$count = $statement->rowCount();
	if ($count > 0) {
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['admin-login-success'] = "Admin Logged in Successfully!";
		header("Location: ../view/rob.php");
	}
	else {
		$_SESSION['admin-login-failed'] = "Login Failed. Please try with valid credentials!";
		header("Location: ../view/admin-login.php");
	}
}

?>






