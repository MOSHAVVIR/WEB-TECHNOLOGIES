<?php
session_start();

require_once "../model/pdo.php";


if ( isset( $_POST['name']) && isset( $_POST['price']) && isset( $_POST['category']) && isset( $_POST['description']) ) {

	// Data validation
	// if ( strlen($_POST['name']) < 1 || strlen($_POST['price']) < 1 || strlen($_POST['category']) < 1 || strlen($_POST['description']) < 1 ) {
 //        $_SESSION['product-add-failed'] = 'Adding Product Failed! Please try with valid data.';
 //        header("Location: ../view/product-add.php");
 //        return;
	// }
//   	if ( strpos($_POST['email'],'@') === false ) {
 //        $_SESSION['error'] = 'Bad data';
 //        header("Location: ../view/admin-register.php");
 //        return;
//   	}

	$sql = "INSERT INTO tbl_products (name, price, category, description) VALUES (:name, :price, :category, :description)";

	$stmt = $pdo->prepare($sql);
	$stmt->execute(array(
        ':name' => $_POST['name'],
        ':price' => $_POST['price'],
        ':category' => $_POST['category'],
        ':description' => $_POST['description']) );
	$_SESSION['product-add-success'] = "Product Added Successfully!";
	header('Location: ../view/products-list.php');
	return;
}
?>


