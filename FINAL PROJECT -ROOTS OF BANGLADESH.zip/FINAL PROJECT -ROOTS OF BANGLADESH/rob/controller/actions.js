// validate form for login

function validateFormForLogin(form) 
{
    var formValid = true;

    if (!form.emailInput.value.length) 
    {
        formValid = false;
        document.getElementById("emailError").style.display = "inline-block";
    }

    if (!form.passwordInput.value.length)
    {
        formValid = false;
        document.getElementById("passwordError").style.display = "inline-block";
    }

    if (!formValid)
    {
        return false;
    }

    return formValid;
}


// onblur login input check for email

function emailInputCheckForLogin(element)
{
    if(!element.value.length) // if email not entered
    {
        document.getElementById("emailError").style.display = "inline-block";
    }
    else // if email entered
    {
        document.getElementById("emailError").style.display = "none";
    }
}


// onblur login input check for password

function passwordInputCheckForLogin(element)
{
    if(!element.value.length) // if email not entered
    {
        document.getElementById("passwordError").style.display = "inline-block";
    }
    else // if email entered
    {
        document.getElementById("passwordError").style.display = "none";
    }
}







// validate form for signup

function validateFormForSignup(form) 
{
    var formValid = true;

    if (!form.fname.value.length) 
    {
        formValid = false;
        document.getElementById("fnameError").style.display = "inline-block";
        document.getElementById("fnameCapitalisationError").style.display = "none";
    }

    else 
    {
        if(document.getElementById("fname").value.match(/^[A-Z]/)) // if fname first letter capitalised
        {
            document.getElementById("fnameCapitalisationError").style.display = "none";
            document.getElementById("fnameError").style.display = "none";
        } 
        else // if fname first letter not capitalised
        {
            formValid = false;
            document.getElementById("fnameCapitalisationError").style.display = "inline-block";
            document.getElementById("fnameError").style.display = "none";
        }
    }

    if (!form.lname.value.length) 
    {
        formValid = false;
        document.getElementById("lnameError").style.display = "inline-block";
        document.getElementById("lnameCapitalisationError").style.display = "none";
    }

    else 
    {
        if(document.getElementById("lname").value.match(/^[A-Z]/)) // if fname first letter capitalised
        {
            document.getElementById("lnameCapitalisationError").style.display = "none";
            document.getElementById("lnameError").style.display = "none";
        } 
        else // if fname first letter not capitalised
        {
            formValid = false;
            document.getElementById("lnameCapitalisationError").style.display = "inline-block";
            document.getElementById("lnameError").style.display = "none";
        }
    }

    if (!form.emailInput.value.length) 
    {
        formValid = false;
        document.getElementById("emailError").style.display = "inline-block";
    }

    if (!form.passwordInput.value.length)
    {
        formValid = false;
        document.getElementById("passwordError").style.display = "inline-block";
    }

    if (!form.street.value.length) 
    {
        formValid = false;
        document.getElementById("streetError").style.display = "inline-block";
    }

    // if (!form.suburb.value.length) 
    // {
    //     formValid = false;
    //     document.getElementById("suburbError").style.display = "inline-block";
    // }

    if (!form.postcode.value.length) 
    {
        formValid = false;
        document.getElementById("postcodeError").style.display = "inline-block";
    }

    if (!formValid)
    {
        return false;
    }

    return formValid;
}





// onblur signup input check for fname

function fnameInputCheckForSignup(element)
{
    if(!element.value.length) // if fname not entered
    {
        document.getElementById("fnameError").style.display = "inline-block";
    }
    else // if email entered
    {
        if(element.value.match(/^[A-Z]/)) // onblur if fname starts with capital letter
        {
            document.getElementById("fnameCapitalisationError").style.display = "none";
            document.getElementById("fnameError").style.display = "none";
        } 
        else // onblur if fname doesn't start with capital letter
        {
            document.getElementById("fnameCapitalisationError").style.display = "inline-block";
            document.getElementById("fnameError").style.display = "none";
        }
    }
}


// onblur signup input check for lname


function lnameInputCheckForSignup(element)
{
    if(!element.value.length) // if lname not entered
    {
        document.getElementById("lnameError").style.display = "inline-block";
    }
    else // if email entered
    {
        if(element.value.match(/^[A-Z]/)) // onblur if lname starts with capital letter
        {
            document.getElementById("lnameCapitalisationError").style.display = "none";
            document.getElementById("lnameError").style.display = "none";
        } 
        else // onblur if lname doesn't start with capital letter
        {
            document.getElementById("lnameCapitalisationError").style.display = "inline-block";
            document.getElementById("lnameError").style.display = "none";
        }
    }
}


// onblur signup input check for email


function emailInputCheckForSignup(element)
{
    if(!document.getElementById("emailInput").value.length) // if email not entered
    {
        formValid = false;
        document.getElementById("emailError").style.display = "inline-block";
        //document.getElementById("emailFormatError").style.display = "none";
    }
    else // if email entered
    {
        //var emailFormatCheck = /^([1-9]{1,1})([0-9]{7,7})\@(student)\.(westernsydney)\.(edu)\.(au)$/;
        //var emailAddressEntered = document.getElementById("emailInput").value;

        //if(emailFormatCheck.test(emailAddressEntered) == true) // if email format is valid
        //{
            //document.getElementById("emailFormatError").style.display = "none";
            //document.getElementById("emailError").style.display = "none";
        //}
        //else // if email format is not valid
        //{
            //formValid = false;
            //document.getElementById("emailFormatError").style.display = "inline-block";
            document.getElementById("emailError").style.display = "none";
        //}
    }
}


// onblur signup input check for password

function passwordInputCheckForSignup(element)
{
    if(!element.value.length) // if password not entered
    {
        document.getElementById("passwordError").style.display = "inline-block";
    }
    else // if password entered
    {
            document.getElementById("passwordError").style.display = "none";
    }
}


// onblur signup input check for street

function streetInputCheckForSignup(element)
{
    if(!element.value.length) // if password not entered
    {
        document.getElementById("streetError").style.display = "inline-block";
    }
    else // if password entered
    {
            document.getElementById("streetError").style.display = "none";
    }
}




// onblur signup input check for state

function stateInputCheckForSignup(element)
{
    if(!element.value.length) // if password not entered
    {
        document.getElementById("stateError").style.display = "inline-block";
    }
    else // if password entered
    {
            document.getElementById("stateError").style.display = "none";
    }
}


// onblur signup input check for postcode

function postcodeInputCheckForSignup(element)
{
    if(!element.value.length) // if password not entered
    {
        document.getElementById("postcodeError").style.display = "inline-block";
    }
    else // if password entered
    {
        document.getElementById("postcodeError").style.display = "none";
    }
}






// onblur checkout input check for credit card name

function inputCheckForCreditCardName(element)
{
    if(!element.value.length) 
    {
        document.getElementById("creditCardNameError").style.display = "inline-block";
    }
    else 
    {
        document.getElementById("creditCardNameError").style.display = "none";
    }
}


// onblur checkout input check for credit card number

function inputCheckForCreditCardNumber(element)
{
    if(!element.value.length) 
    {
        document.getElementById("creditCardNumberError").style.display = "inline-block";
    }
    else 
    {
        document.getElementById("creditCardNumberError").style.display = "none";
    }
}




// onblur checkout input check for credit card number expiry

function inputCheckForCreditCardExpiry(element)
{
    if(!element.value.length)
    {
        document.getElementById("creditCardExpiryError").style.display = "inline-block";
    }
    else 
    {
        document.getElementById("creditCardExpiryError").style.display = "none";
    }
}



// onblur checkout input check for credit card number csv

function inputCheckForCSV(element)
{
    if(!element.value.length) 
    {
        document.getElementById("csvError").style.display = "inline-block";
    }
    else 
    {
        document.getElementById("csvError").style.display = "none";
    }
}








// validate form for payment

function validateFormForCheckout(form) 
{
    var formValid = true;

    if (!form.creditCardNameInput.value.length) 
    {
        formValid = false;
        document.getElementById("creditCardNameError").style.display = "inline-block";
    }

    if (!form.creditCardNumberInput.value.length)
    {
        formValid = false;
        document.getElementById("creditCardNumberError").style.display = "inline-block";
    }

    if (!form.expiryDateInput.value.length)
    {
        formValid = false;
        document.getElementById("creditCardExpiryError").style.display = "inline-block";
    }

    if (!form.csvInput.value.length)
    {
        formValid = false;
        document.getElementById("csvError").style.display = "inline-block";
    }

    if (!formValid)
    {
        return false;
    }

    return formValid;
}













