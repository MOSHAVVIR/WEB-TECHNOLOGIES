<?php 
session_start();
?>

<html>
    <head>
      <style>
          .box{
      width: 1346px;
      height: 600px;
      text-align: center;
      padding: 0px;
      margin: 0px;
      border: 3px auto;
      background-image:url(../data/bg.jpg); 
    }
    .red-button{
      font-size: 20px;
      border-radius: 9px;
      padding: 10px 7px;
      background-color: #FA0303;
      color: #ffffff;
      text-decoration: none;
    }
    a.red-button:hover{
      text-decoration: none;
      background-color: #B00000;
      color: #ffffff;
      transition: 0.9s;
    }
      </style>
        <title>Add Accountant - Roots of Bangladesh</title>
        <script src="../controller/actions.js"></script>
        <link rel="stylesheet" type="text/css" href="../controller/styles.css">
        <style>
          h1 {text-align: center;}
        </style>
    </head>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>
<body>



<?php
if( isset($_SESSION['product-add-failed']) ) {
  echo('<p style="color:red">'.$_SESSION['product-add-failed'].'</p>');
  unset($_SESSION['product-add-failed']);
}


// Check if already logged in! ?>

<?php 

if ( !isset($_SESSION['email']) ) {
	header("Location: rob.php");
} else { ?>

	<html>
	<head>
		<title>Add Product - Roots of Bangladesh</title>
	</head>
	<body>
    <div class="box">
      <h1><font color=" #E6E2E1"><?php include '../view/header.php' ?></h1></font>
		<h1>Add Product</h1>
		<form action="../controller/product-add-validation.php" method="post">
			<label>Product Name:</label>
			<input id="id-name" type="text" name="name" placeholder="Enter Product Name"><br>
			<label>Price:</label>
			<input id="id-price" type="text" name="price" placeholder="Enter product price"><br>
			<label>Category:</label>
			<input id="id-category" type="text" name="category" placeholder="Enter product category"><br>
			<label>Description:</label>
			<input id="id-description" type="text" name="description" placeholder="Enter product description"><br><br>

			<input type="submit" name="add-submit" value="Add Product"><br><br>
			<!-- <a href="rob.php">Cancel</a></p> -->
      <a href="rob.php" class="red-button">CANCEL</a>
      <h1><font color=" #E6E2E1"><?php include '../view/footer.php' ?></h1>
		</form>
    </div>
	</body>
	</html>

<?php
}

?>
