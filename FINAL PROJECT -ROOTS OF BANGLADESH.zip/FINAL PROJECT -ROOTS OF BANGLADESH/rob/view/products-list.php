<?php
session_start();
require_once "../model/pdo.php";

?>

<html>
    <head>
        <style>
               .button{
            font-size: 20px;
            border-radius: 9px;
            padding: 10px 7px;
            background-color: #020B6A ;
            color: #ffffff;
            text-decoration: none;
        }
        a.button:hover{
            text-decoration: none;
            background-color: #0818B9 ;
            color: #ffffff;
            transition: 0.9s;
        }
        </style>
        <title>Add Accountant - Roots of Bangladesh</title>
        <script src="../controller/actions.js"></script>
        <link rel="stylesheet" type="text/css" href="../controller/styles.css">
    </head>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>
<body>
    <center>



<?php
if ( isset($_SESSION["product-add-success"]) ) {
    echo '<p style="color:green">'.$_SESSION['product-add-success']."</p>\n";
    unset($_SESSION['product-add-success']);
}

if ( isset($_SESSION["product-edit-success"]) ) {
    echo '<p style="color:green">'.$_SESSION['product-edit-success']."</p>\n";
    unset($_SESSION['product-edit-success']);
}

if ( isset($_SESSION["product-delete-success"]) ) {
    echo '<p style="color:green">'.$_SESSION['product-delete-success']."</p>\n";
    unset($_SESSION['product-delete-success']);
}

// Checkk if logged in

if ( !isset($_SESSION['email']) ) {
    header("Location: rob.php");
} else {
    echo "<title>All Products - Roots of Bangladesh</title>";
echo "<h1>Products:</h1>";
echo('<table border="1">'."\n");
$sql = "SELECT id, name, price, category, description FROM tbl_products";
$stmt = $pdo->query($sql);
while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
    echo "<tr><td>";
    // echo( $row['name'] );
    echo( htmlentities($row['name']) );
    echo("</td><td>");
    echo("$");
    echo(htmlentities($row['price']));
    echo("</td><td>");
    echo(htmlentities($row['category']));
    echo("</td><td>");
    echo(htmlentities($row['description']));
    echo("</td><td>");
    echo('<a href="product-edit.php?id='.$row['id'].'">Edit</a> / ');
    echo('<a href="product-delete.php?id='.$row['id'].'">Remove</a>');
    echo("</td></tr>\n");
}
?>
</table><br>


<br>
<a href="product-add.php" class="button">Add product</a>
<!-- <a href="accountant-add.php">Add Accountant</a><br><br> -->
<a href="rob.php" class="button">Go back</a>

<!-- <a href="product-add.php">Add Product</a><br><br>
<a href="rob.php">Go back</a></p> -->
</center>

<?php
}
?>









