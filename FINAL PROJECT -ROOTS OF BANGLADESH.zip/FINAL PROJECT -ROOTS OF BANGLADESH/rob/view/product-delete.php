<?php
session_start();
require_once "../model/pdo.php";
?>

<html>
    <head>
        <title>Add Accountant - Roots of Bangladesh</title>
        <script src="../controller/actions.js"></script>
        <link rel="stylesheet" type="text/css" href="../controller/styles.css">

        <style>
          h1 {text-align: center;}
        </style>
    </head>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>
<body>


<?php

if ( isset($_POST['delete']) && isset($_POST['id']) ) {
    $sql = "DELETE FROM tbl_products WHERE id = :zip";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(':zip' => $_POST['id']));
    $_SESSION['product-delete-success'] = 'Product removed!';
    header( 'Location: products-list.php' ) ;
    return;
}

// Make sure that id is present
if ( ! isset($_GET['id']) ) {
  $_SESSION['product-delete-id-error'] = "Missing id";
  header('Location: products-list.php');
  return;
}

$stmt = $pdo->prepare("SELECT name, id FROM tbl_products WHERE id = :xyz");
$stmt->execute(array(":xyz" => $_GET['id']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ( $row === false ) {
    $_SESSION['product-delete-id-error'] = 'Bad value for id';
    header( 'Location: rob.php' );
    return;
}

?>

<html>
<head>
  <title>Remove Product - Roots of Bangladesh</title>
</head>
<body>
  <h1>Confirm: Removing <?= htmlentities($row['name']) ?></h1>
  <form method="post">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">
    <input type="submit" value="Remove" name="delete">
    <a href="products-list.php">Cancel</a>
</form>
</body>
</html>
