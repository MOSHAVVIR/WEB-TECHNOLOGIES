<?php
session_start();
require_once "../model/pdo.php";
?>


<html>
    <head>
        <title>Add Accountant - Roots of Bangladesh</title>
        <script src="../controller/actions.js"></script>
        <link rel="stylesheet" type="text/css" href="../controller/styles.css">

        <style>
          h1 {text-align: center;}
        </style>
    </head>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>
<body>




<?php

if ( isset($_POST['name']) && isset($_POST['price'])
     && isset($_POST['category']) && isset($_POST['description']) &&  isset($_POST['id']) ) {

    // Data validation
    if ( strlen($_POST['name']) < 1 ) {
        $_SESSION['error'] = 'Missing data';
        header("Location: product-edit.php?id=".$_POST['id']);
        return;
    }


    $sql = "UPDATE tbl_products SET name = :name,
            price = :price, category = :category, description = :description
            WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ':name' => $_POST['name'],
        ':price' => $_POST['price'],
        ':category' => $_POST['category'],
        ':description' => $_POST['description'],
        ':id' => $_POST['id']));
    $_SESSION['product-edit-success'] = 'Product updated!';
    header( 'Location: products-list.php' ) ;
    return;
}

// Make sure that id is present
if ( ! isset($_GET['id']) ) {
  $_SESSION['error'] = "Missing id";
  header('Location: products-list.php');
  return;
}

$stmt = $pdo->prepare("SELECT * FROM tbl_products where id = :xyz");
$stmt->execute(array(":xyz" => $_GET['id']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ( $row === false ) {
    $_SESSION['error'] = 'Bad value for id';
    header( 'Location: products-list.php' ) ;
    return;
}

// Flash pattern
if ( isset($_SESSION['error']) ) {
    echo '<p style="color:red">'.$_SESSION['error']."</p>\n";
    unset($_SESSION['error']);
}

$n = htmlentities($row['name']);
$e = htmlentities($row['price']);
$p = htmlentities($row['category']);
$d = htmlentities($row['description']);
$id = $row['id'];
?>
<h1>Edit Product</h1>
<form method="post">
    <p>Name:<input type="text" name="name" value="<?= $n ?>"></p>
    <p>Price:<input type="text" name="price" value="<?= $e ?>"></p>
    <p>Category:<input type="text" name="category" value="<?= $p ?>"></p>
    <p>Description:<input type="text" name="description" value="<?= $d ?>"></p>
    <input type="hidden" name="id" value="<?= $id ?>">
    <p><input type="submit" value="Update"/>
    <a href="products-list.php">Cancel</a></p>
</form>



