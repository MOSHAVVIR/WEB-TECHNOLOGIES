<?php 
session_start();

if( isset($_SESSION['admin-login-failed']) ) {
  echo('<p style="color:red">'.$_SESSION['admin-login-failed'].'</p>');
  unset($_SESSION['admin-login-failed']);
}

// Check if already logged in! ?>
<?php 
if ( !isset($_SESSION["email"]) ) { ?>
	<html>
	<head>
		<title>Admin Login - Roots of Bangladesh</title>
		<script src="../controller/actions.js"></script>
		<link rel="stylesheet" type="text/css" href="../controller/styles.css">

		<style>
          h1 {text-align: center;}
          .box{
			width: 1346px;
			height: 600px;
			text-align: center;
			padding: 0px;
			margin: 0px;
			border: 3px auto;
			background-image:url(../data/bg.jpg); 
		}
		.red-button{
			font-size: 20px;
			border-radius: 9px;
			padding: 10px 7px;
			background-color: #FA0303;
			color: #ffffff;
			text-decoration: none;
		}
		a.red-button:hover{
			text-decoration: none;
			background-color: #B00000;
			color: #ffffff;
			transition: 0.9s;
		}
        </style>
	</head>
	<body>
		<header>
			<nav class="navbar">
				<div>
                <a href="rob.php">HOME</a>
            	</div>
            	<div class="navbarForUsers">
                	<a href="admin-register.php">REGISTER</a>
            	</div>
        	</nav>
    	</header>
    	<div class="box">
    		<h1><font color=" #E6E2E1"><?php include '../view/header.php' ?></h1></font>
		<h1>Admin Login Page</h1>
		<!-- <form action="../controller/admin-login-validation.php" method="post"> -->
		<form method="post" action="../controller/admin-login-validation.php" onsubmit="return validateFormForLogin(this);">
			<div>
				<label for="email">Email</label>
				<input type="text" id="emailInput" name="email" placeholder="Enter Admin Email" onblur="emailInputCheckForLogin(this);">
            	<span class="error" id="emailError" style="display: none;">Email is required</span>
			</div>

			<div>
				<label for="password">Password</label>
            	<input type="text" id="passwordInput" name="password" placeholder="Enter Password" onblur="passwordInputCheckForLogin(this);">
            	<span class="error" id="passwordError" style="display: none;">Password is Required</span>
			</div>

			<div>
				<hr>
            </div>
            <div>
            	<input type="submit" name="login-submit" value="Login">
            </div><br>

            <a href="rob.php" class="red-button">CANCEL</a>
			<h1><font color=" #E6E2E1"><?php include '../view/footer.php' ?></h1>
			<!-- <a href="rob.php">Cancel</a> -->
		</form>
	</div>
	</body>
	</html>

<?php 
} 
else {
	header('Location: ../view/rob.php'); ?>
<?php 
} 
?>
