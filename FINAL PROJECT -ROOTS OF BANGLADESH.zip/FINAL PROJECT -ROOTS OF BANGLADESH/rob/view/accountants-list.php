<?php
session_start();
require_once "../model/pdo.php";?>

<html>
    <head>
        <style>
            .button{
            font-size: 20px;
            border-radius: 9px;
            padding: 10px 7px;
            background-color: #020B6A ;
            color: #ffffff;
            text-decoration: none;
        }
        a.button:hover{
            text-decoration: none;
            background-color: #0818B9 ;
            color: #ffffff;
            transition: 0.9s;
        }
        </style>
        <title>Add Accountant - Roots of Bangladesh</title>
        <script src="../controller/actions.js"></script>
        <link rel="stylesheet" type="text/css" href="../controller/styles.css">
    </head>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>
<body>
    <center>


<?php
if ( isset($_SESSION["accountant-delete-success"]) ) {
    echo '<p style="color:green">'.$_SESSION['accountant-delete-success']."</p>\n";
    unset($_SESSION['accountant-delete-success']);
}

// Checkk if logged in

if ( !isset($_SESSION['email']) ) {
    header("Location: rob.php");
} else {
    echo "<title>All Accountants - Roots of Bangladesh</title>";
    echo "<h1>Accountants:</h1>";
    echo('<table border="1">'."\n");
    $stmt = $pdo->query("SELECT id, fname, lname, email FROM tbl_accountant");
    while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
        echo "<tr><td>";
        echo(htmlentities($row['fname']));
        echo("</td><td>");
        echo(htmlentities($row['lname']));
        echo("</td><td>");
        echo(htmlentities($row['email']));
        echo("</td><td>");
        // echo('<a href="accountant-edit.php?id='.$row['id'].'">Edit</a> / ');
        echo('<a href="accountant-delete.php?id='.$row['id'].'">Remove</a>');
        echo("</td></tr>\n");
    }
    ?>
</table><br>
<div>
    <a href="accountant-add.php" class="button">Add Accountant</a>
<!-- <a href="accountant-add.php">Add Accountant</a><br><br> -->
<a href="rob.php" class="button">Go back</a>
<!-- <a href="rob.php">Go back</a></p> -->
</div>
<?php
}
?>
</center>
</body>

