<!DOCTYPE html>
<html>
<body>

<footer>
  <p>COPYRIGHT &copy; 1999-2021.</p>
</footer>

</body>
</html>