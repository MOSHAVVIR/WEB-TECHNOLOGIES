<?php 
session_start();
 ?>

<header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
</header>

<?php 

if ( !isset($_SESSION['email']) ) {
	header("Location: rob.php");
} else { ?>


<?php

if( isset($_SESSION['accountant-add-failed']) ) {
  echo('<p style="color:red">'.$_SESSION['accountant-add-failed'].'</p>');
  unset($_SESSION['accountant-add-failed']);
}
?>

	<html>
	<head>
		<style>
			.box{
			width: 1346px;
			height: 800px;
			text-align: center;
			padding: 0px;
			margin: 0px;
			border: 3px auto;
			background-image:url(../data/bg.jpg); 
		}
		.red-button{
			font-size: 20px;
			border-radius: 9px;
			padding: 10px 7px;
			background-color: #FA0303;
			color: #ffffff;
			text-decoration: none;
		}
		a.red-button:hover{
			text-decoration: none;
			background-color: #B00000;
			color: #ffffff;
			transition: 0.9s;
		}
		</style>
		<title>Add Accountant - Roots of Bangladesh</title>
		<script src="../controller/actions.js"></script>
		<link rel="stylesheet" type="text/css" href="../controller/styles.css">

		<style>
          h1 {text-align: center;}
        </style>
	</head>
	<body>
		<div class="box">
			<h1><font color=" #E6E2E1"><?php include '../view/header.php' ?></h1></font>
		<h1>Add Accountant</h1>
		<form action="../controller/accountant-add-validation.php" method="post"onsubmit="return validateFormForSignup(this);">
			<div>
				<label for="fname">First Name:</label>
				<input id="id-fname" type="text" name="fname" placeholder="first Name"onblur="fnameInputCheckForSignup(this);">
				<span class="error" id="fnameError" style="display: none;">First Name is required</span>
	            <span class="error" id="fnameCapitalisationError">First Name must start with a capital letter</span>
			</div>

			<div>
            <label for="lname">Last Name</label>
	            <input type="text" name="lname" id="lname" placeholder="Last Name" onblur="lnameInputCheckForSignup(this);">
	            <span class="error" id="lnameError" style="display: none;">Last Name is required</span>
	            <span class="error" id="lnameCapitalisationError">Last Name must start with a capital letter</span>
	        </div>

	        <div>
	        	<label for="email">Email</label>
            	<input type="text" name="email" id="emailInput" placeholder="Email" onblur="emailInputCheckForSignup(this);">
            	<span class="error" id="emailError" style="display: none;">Email is required</span>
            	<span class="error" id="emailFormatError">Your Email address must be entered in a valid email address format</span>
        	</div>

        	<div>
	            <label for="password">Password</label>
	            <input type="text" name="password" id="passwordInput" placeholder="Password" onblur="passwordInputCheckForSignup(this);">
	            <span class="error" id="passwordError" style="display: none;">Password is Required</span>
	        </div>

	        <div>
	            <label for="street">Address</label>
	            <input type="text" name="address" id="street" placeholder="Address" onblur="streetInputCheckForSignup(this);">
	            <span class="error" id="streetError" style="display: none;">Address is required</span>
	        </div>

	        <div>
	            <label for="postcode">Phone</label>
	            <input type="text" name="phone" id="postcode" placeholder="Phone" onblur="postcodeInputCheckForSignup(this);">
	            <span class="error" id="postcodeError" style="display: none;">Phone is required</span>
        	</div>

<!-- 
			<div>
			<label>Last Name:</label>
			<input id="id-fname" type="text" name="lname" placeholder="Your last Name" ><br>
			</div>

			<label>Email:</label>
			<input id="id-email" type="text" name="email" placeholder="Enter your email address"><br>
			<label>Password:</label>
			<input id="id-password" type="text" name="password" placeholder="Enter your password"><br>
			<label>Address:</label>
			<input id="id-address" type="text" name="address" placeholder="Your address"><br>
			<label>Phone:</label>
			<input id="id-password" type="text" name="phone" placeholder="Your phone number"><br><br>
			<input type="submit" name="register-submit" value="Add Accountant"><br><br>
			<!- <a href="rob.php">Cancel</a></p> --> 
			<br>
			<input type="submit" name="register-submit" value="Add Accountant"><br><br>
			
			<a href="rob.php" class="red-button">CANCEL</a>
			<h1><font color=" #E6E2E1"><?php include '../view/footer.php' ?></h1>
		</form>
	</div>
	</body>
	</html>

<?php
}

?>
