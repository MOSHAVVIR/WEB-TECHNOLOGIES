<?php
session_start();
?>

<html>
<head>
	<style>

		.box{
			width: 1346px;
			height: 600px;
			text-align: center;
			padding: 0px;
			margin: 0px;
			border: 3px auto;
			background-image:url(../data/bg.jpg); 
		}
		.btn{
			background: none;
			font-size: 15px;
			padding: 7px 10px;
			margin: 10px;
		}
		.red-button{
			font-size: 20px;
			border-radius: 9px;
			padding: 10px 7px;
			background-color: #FA0303;
			color: #ffffff;
			text-decoration: none;
		}
		a.red-button:hover{
			text-decoration: none;
			background-color: #B00000;
			color: #ffffff;
			transition: 0.9s;
		}
		.box1{
			width: 250px;
			height: 70px;
			text-align: center;
			padding: 0px;
			margin: 10px;
			border: 3px solid black;
			background-color: #C8D1C7;
			border-radius: 9px;
		}
		/*.accountantbox{
			left: 280px;
			width: 250px;
			height: 70px;
			text-align: center;
			padding: 0px;
			margin: 10px;
			border: 3px solid black;
			background-color: #C8D1C7;
			border-radius: 9px;
		}
		.receptionistbox{
			left: 280px;
			width: 250px;
			height: 70px;
			text-align: center;
			padding: 0px;
			margin: 10px;
			border: 3px solid black;
			background-color: #C8D1C7;
			border-radius: 9px;
		}*/
	</style>
  <title>Home - Roots of Bangladesh</title>
  <script src="../controller/actions.js"></script>
  <link rel="stylesheet" type="text/css" href="../controller/styles.css">
</head>
<body>
<center>
<?php // Check if logged in! ?>
<?php 
if ( ! isset($_SESSION["email"]) ) { ?>
  <header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
      </div>
      <div class="navbarForUsers">
        <a href="admin-login.php">ADMIN LOGIN</a>
        <a href="admin-register.php">ADMIN REGISTER</a>
      </div>
    </nav>
  </header>

  <?php 

  if ( isset($_SESSION['admin-register-success']) ) {
    echo '<p style="color:green">'.$_SESSION['admin-register-success']."</p>\n";
    unset($_SESSION['admin-register-success']);
  }
  if ( isset($_SESSION["accountant-add-success"]) ) {
    echo '<p style="color:green">'.$_SESSION['accountant-add-success']."</p>\n";
    unset($_SESSION["accountant-add-success"]);
  }

  ?>

    <div class="box">
      <center>
    	<h1><font color=" #E6E2E1"><?php include '../view/header.php' ?></h1>
    		<div class="box1">
    			<div>
      				<p><a href="admin-login.php">LOGIN AS ADMIN</a></p></font>
    			</div>

    			<div>
      				<p><a href="admin-register.php">REGISTER AS ADMIN</a></p>
    			</div>
    		</div>

    		<div class="box1">
    			<div>
     		 		<p><a href="#">LOGIN AS ACCOUNTANT</a></p>
    			</div>
    	
    			<div>
     		 		<p><a href="#">REGISTER AS ACCOUNTANT</a></p>
    			</div>
    		</div>
    		
			<div class="box1">
				<div>
      				<p><a href="#">LOGIN AS RECEPTIONIST</a></p>
    			</div>
    	
    			<div>
      				<p><a href="#">REGISTER AS RECEPTIONIST</a></p>
    			</div>
    		</div>
    			
    		<div class="box1">
    			<div>
      				<p><a href="#">LOGIN AS CUSTOMER</a></p>
    			</div>
    
        		<div>
        			<p><a href="#">REGISTER AS CUSTOMER</a></p>
        		</div>
        	</div>	

      <h1><font color=" #E6E2E1"><?php include '../view/footer.php' ?></h1>
        </center>
    </div>
    

<?php } else { ?>
  <header>
    <nav class="navbar">
      <div>
        <a href="rob.php">HOME</a>
        <a href="accountant-add.php">Add Accountant</a>
        <a href="accountants-list.php">Show Accountants</a>
        <a href="product-add.php">Add Product</a>
        <a href="products-list.php">Show Products</a>
      </div>
      <div class="navbarForUsers">
        <a href="logout.php">LOGOUT</a>
      </div>
    </nav>
  </header>

<?php

if ( isset($_SESSION["admin-login-success"]) ) {
  echo '<p style="color:green">'.$_SESSION['admin-login-success']."</p>\n";
  unset($_SESSION["admin-login-success"]);
}


?>

  <h1>Welcome to Admin Panel</h1>

<?php

  require_once "../model/pdo.php";
 
// echo('<table border="1">'."\n");

$stmt = $pdo->query( " SELECT fname, lname, email, address, phone FROM tbl_admin WHERE email = '".$_SESSION['email']."' " );

while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
  echo("Hello, ");
  echo( htmlentities($row['fname']) );
  echo(" ");
  echo(htmlentities($row['lname']));
  echo(".");
  echo("<br>");
  echo('You are logged in as an ADMIN using "');
  echo( htmlentities($row['email']) );
  echo('" as your email.');
  echo("<br>");
  echo("Your address: ");
  echo(htmlentities($row['address']));
  echo("<br>");
  echo("Your phone number: ");
  echo(htmlentities($row['phone']));
  // echo("</td>");

}
?>
<?php 
// echo("</table>") 
?>

 <br><br><br>
<a href="logout.php" class="red-button">LOG OUT</a>

<?php 
}

?>
</center>
</body>
</html>

