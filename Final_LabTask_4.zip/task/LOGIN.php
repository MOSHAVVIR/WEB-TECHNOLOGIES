<!DOCTYPE html>
<html>
<head>
	<title>LOGIN FORM</title>
</head>
<body>
	<center>
	<h1>LOGIN HERE</h1>
	
	<form method ="post" action="connct.php">
		Username : <input type="text" name="username" placeholder="Enter Your Username" required>
		<br><br>
		Password : <input type="password" name="password" placeholder="Enter Your Password" required>
		<br><br>
		<input type="submit" name="submit" value="submit">
		
	</form>
	</center>

</body>
</html>